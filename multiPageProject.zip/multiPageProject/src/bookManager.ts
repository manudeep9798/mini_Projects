import { event } from "jquery";

let booksArray:any=localStorage.getItem("booksArray")!;
if(!booksArray){
    booksArray=[];
}else{
    booksArray=JSON.parse(booksArray);
}
export class BookManager{
constructor(){}

deleteData(deleteID:any){
    console.log(deleteID);
    booksArray.splice(deleteID.id,1);
    localStorage.setItem("booksArray",JSON.stringify(booksArray));
    location.href="index.html";
    this.displayBooks();
}

searchBook(){
    const searchVal=document.getElementById("searchValue")! as HTMLInputElement;
    const optionChoosen:HTMLSelectElement=document.getElementById("dropdown")! as HTMLSelectElement;
    this.displayBooks(searchVal.value,optionChoosen.value);
    // event.preventDefault();
    
}

compare(inputVal:any,listval:any){
   if (listval.search(inputVal) == -1) {
    return false;
}
else {
    return true;
}   
}

 displayBooks(searchVal="",optionSelected=""){
    clearList();
    //  console.log("inside display")
    //let booksArray:any=JSON.parse(localStorage.getItem("booksArray")!) 
        if(searchVal==""&&optionSelected==""){

            for(let i=0;i<booksArray.length;i++)
            {
                var row=document.getElementById("content");
                if(row){
                    row.innerHTML += `<tr><td>  ${booksArray[i].id}  </td>
                     <td>  ${booksArray[i].title} </td>
                     <td>  ${booksArray[i].author} </td>
                     <td> ${booksArray[i].rating} </td>
                     <td> <button type="submit" class="deleteButtons" id=${i}><i class="fas fa-trash"></i></button></td>
                     </tr>`;
                }
            }   
        }
        else{
            
            if(optionSelected==="searchById"){
                
                    for(let i=0;i<booksArray.length;i++){
                        if(booksArray[i].id===searchVal){
                            var row=document.getElementById("content");
                            if(row){
                                 row.innerHTML += `<tr><td>  ${booksArray[i].id}  </td>
                                 <td>  ${booksArray[i].title} </td>
                                 <td>  ${booksArray[i].author} </td>
                                 <td> ${booksArray[i].rating} </td>
                                 <td> <button type="submit" class="deleteButtons" id=${i}><i class="fas fa-trash"></i></button></td>
                                 </tr>`;
                            }  
                        }
                    }
                }
                if(optionSelected==="searchByTitle"){
                    for(let i=0;i<booksArray.length;i++){
                        searchVal=searchVal.toUpperCase();
                        booksArray[i].title.toUpperCase();
                        if(this.compare(searchVal,booksArray[i].title)){
                            
                            
                            
                            var row=document.getElementById("content");
                            if(row){
                                 row.innerHTML += `<tr><td>  ${booksArray[i].id}  </td>
                                 <td>  ${booksArray[i].title} </td>
                                 <td>  ${booksArray[i].author} </td>
                                 <td> ${booksArray[i].rating} </td>
                                 <td> <button type="submit" class="deleteButtons" id=${i}><i class="fas fa-trash"></i></button></td>
                                 </tr>`;
                            }  
                        }
                    }
                }
                if(optionSelected==="searchByAuthor"){
                
                    for(let i=0;i<booksArray.length;i++){
                        searchVal=searchVal.toUpperCase();
                        booksArray[i].author.toUpperCase();
                        if(this.compare(searchVal,booksArray[i].author)){
                            console.log("done search")
                            var row=document.getElementById("content");
                            if(row){
                                 row.innerHTML += `<tr><td>  ${booksArray[i].id}  </td>
                                 <td>  ${booksArray[i].title} </td>
                                 <td>  ${booksArray[i].author} </td>
                                 <td> ${booksArray[i].rating} </td>
                                 <td> <button type="submit" class="deleteButtons" id=${i}><i class="fas fa-trash"></i></button></td>
                                 </tr>
                                 `;
                            }  
                        }
                    }
                }
                if(optionSelected==="searchByRating"){
                
                    for(let i=0;i<booksArray.length;i++){
                        if(booksArray[i].rating>=searchVal){
                            var row=document.getElementById("content");
                            if(row){
                                 row.innerHTML += `<tr><td>  ${booksArray[i].id}  </td>
                                 <td>  ${booksArray[i].title} </td>
                                 <td>  ${booksArray[i].author} </td>
                                 <td> ${booksArray[i].rating} </td>
                                 <td> <button type="submit" class="deleteButtons" id=${i}><i class="fas fa-trash"></i></button></td>
                                 </tr>
                                 `;
                            }  
                        }
                    }
                }
                
            
        }
    }

    addBooks(){
        // console.log("inside addBooks")
        //let booksArray:any=JSON.parse(localStorage.getItem("booksArray")!)
        let Id= (<HTMLInputElement>document.getElementById("idInput")).value;
        let title= (<HTMLInputElement>document.getElementById("titleInput")).value;
        let Author= (<HTMLInputElement>document.getElementById("authorInput")).value;
        let Rating= (<HTMLInputElement>document.getElementById("ratingInput")).value;
    
        if(Id!==""&&title!==""&&Author!==""&&Rating!==""){
            const newBook={
                id:Id,
                title : title.toUpperCase(),
                author:Author.toUpperCase(),
                rating:Rating
            }
            booksArray.push(newBook);
            localStorage.setItem("booksArray",JSON.stringify(booksArray));
            alert("Book Added")
        }
        else{
            alert("enter all the fields")
        }
    
    }
    

}
let tab=document.getElementById("content")!;
     function clearList() {
        tab.innerText="";

    }


