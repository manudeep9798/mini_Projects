
import {BookManager} from "./bookManager.js";
class Book{
    id:string;
    title:string;
    author:string;
    rating:string;
    constructor(id:string,title:string,author:string,rating:string)
    {
        this.id=id;
        this.title=title;
        this.author=author;
        this.rating=rating;
    }
}


//     var booksArray=[{
//         id:"1",
//         title:"Where the crawdads sing",
//         author:"Delia Owens",
//         rating:"5"
//     },
//     {
//         id:"2",
//         title:"Wings of fire",
//         author:"A.P.J Abdul Kalam",
//         rating:"4.2"
//     }];

// localStorage.setItem("booksArray",JSON.stringify(booksArray));
let manager:BookManager=new BookManager();

    manager.displayBooks();



