import {BookManager} from "./bookManager.js";

let manager:BookManager=new BookManager();

let delButton=document.querySelectorAll(".deleteButtons")! as NodeListOf<HTMLButtonElement>;
delButton.forEach((btn:any)=>{
    btn.addEventListener("click",(event:any)=>{
        manager.deleteData(event.target);
        // if(btn===event.target){
        //     manager.deleteData(event.target);
        // }
        // else{
        //     manager.deleteData(event.target.parentElement);
        // }
    })!;
})
