import { BookManager } from "./bookManager.js";
let manager = new BookManager();
// const optionSelected: HTMLSelectElement=document.getElementById("dropdown")! as HTMLSelectElement;
// const searchVal=document.getElementById("searchValue")! as HTMLInputElement;
// console.log(searchVal.value);
const searchButton = document.getElementById("searchButton");
const button = document.querySelector("#searchButton");
function search() {
    manager.searchBook();
}
button.addEventListener("click", search);
// const Button=document.getElementById("searchButton")!;
// // let searchVal= (<HTMLInputElement>document.getElementById("searchValue")).value;
// console.log(searchVal.value)
// function search(){
//     manager.searchBook()
// }
// Button.addEventListener("click",search);
