import { BookManager } from "./bookManager.js";
let manager = new BookManager();
let delButton = document.querySelectorAll(".deleteButtons");
delButton.forEach((btn) => {
    btn.addEventListener("click", (event) => {
        manager.deleteData(event.target);
        // if(btn===event.target){
        //     manager.deleteData(event.target);
        // }
        // else{
        //     manager.deleteData(event.target.parentElement);
        // }
    });
});
