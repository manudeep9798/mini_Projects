import { BookManager } from "./bookManager.js";
class Book {
    constructor(id, title, author, rating) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.rating = rating;
    }
}
//     var booksArray=[{
//         id:"1",
//         title:"Where the crawdads sing",
//         author:"Delia Owens",
//         rating:"5"
//     },
//     {
//         id:"2",
//         title:"Wings of fire",
//         author:"A.P.J Abdul Kalam",
//         rating:"4.2"
//     }];
// localStorage.setItem("booksArray",JSON.stringify(booksArray));
let manager = new BookManager();
manager.displayBooks();
