import { BookManager } from "./bookManager.js";
let manager = new BookManager();
function add() {
    manager.addBooks();
}
const addButton = document.getElementById("submit");
addButton.addEventListener("click", add);
