let gotoAddBookBtn=document.getElementById("goToAddBook")!;

gotoAddBookBtn.addEventListener("click",()=>{
    document.getElementById("bookListBody")!.style.display="none";
    document.getElementById("addBookBody")!.style.display="block";
})

let gotoBookListBtn=document.getElementById("goToBookList")!;

gotoBookListBtn.addEventListener("click",()=>{
    document.getElementById("bookListBody")!.style.display="block";
    document.getElementById("addBookBody")!.style.display="none";
})